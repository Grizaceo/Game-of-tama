class_name MutationEngine
extends RefCounted

const OXIDATION_MUTATION_THRESHOLD = 50

static func apply_tick(pet: PetState) -> bool:
	var mutated: bool = false
	var current_hash: int = _calculate_base_hash(pet.genome)
	
	if pet.oxidation_level >= OXIDATION_MUTATION_THRESHOLD:
		current_hash |= GeneCatalog.Tags.OXIDO
	
	if (current_hash & GeneCatalog.Tags.OXIDO) != 0:
		if pet.genome["head"]["dom"] == 100:
			pet.genome["head"]["dom"] = 102
			mutated = true
			
	if mutated:
		pet.ecosystem_hash = _calculate_base_hash(pet.genome)
		pet.genome_mutated.emit()
	
	return mutated

static func _calculate_base_hash(genome: Dictionary) -> int:
	var hash_val: int = 0
	hash_val |= GeneCatalog.get_mask(genome["head"]["dom"])
	hash_val |= GeneCatalog.get_mask(genome["body"]["dom"])
	hash_val |= GeneCatalog.get_mask(genome["aura"]["dom"])
	return hash_val