class_name TickManager
extends RefCounted

const SECONDS_PER_TICK: int = 3600
const MAX_CATCHUP_TICKS: int = 720
const HUNGER_DECAY: int = -5
const OXIDATION_RATE: int = 2

static func catch_up(pet: PetState, current_unix_time: int) -> int:
	var delta_time: int = current_unix_time - pet.last_interaction
	if delta_time < SECONDS_PER_TICK: return 0
		
	var missed_ticks: int = delta_time / SECONDS_PER_TICK
	var ticks_to_process: int = mini(missed_ticks, MAX_CATCHUP_TICKS)
	
	for i in range(ticks_to_process):
		pet.feed(HUNGER_DECAY)
		pet.add_oxidation(OXIDATION_RATE)
		MutationEngine.apply_tick(pet)
		
	pet.last_interaction += (missed_ticks * SECONDS_PER_TICK)
	pet.status_updated.emit()
	return ticks_to_process